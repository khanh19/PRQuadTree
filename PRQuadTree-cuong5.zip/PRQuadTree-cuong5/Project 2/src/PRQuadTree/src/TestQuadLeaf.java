
public class TestQuadLeaf extends student.TestCase{

}
