public class DatabaseHandler<K extends Comparable<K>, E> {
    
}